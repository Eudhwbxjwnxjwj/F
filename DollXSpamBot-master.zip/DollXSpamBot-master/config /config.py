


from os import getenv

from dotenv import load_dotenv

()

API_ID = int(getenv("API_ID", ""))
API_HASH = getenv("API_HASH")

# ADMIN DETAILS (Your ID) 

OWNER_ID = int(getenv("OWNER_ID", ""))

OWNER_NAME = getenv("OWNER_NAME") 

SUDO_USER= list(

    map(int, getenv("SUDO_USER", "5937170640").split())

)

# BOT TOKEN CONFIG VARS (get all vars detail from @botfather) 

n
f("CMD_HNDLR") 

LUND = list(

    map(int, getenv("LUND", "123456789").split())

)

CHUT = list(

    map(int, getenv("CHUT", "1234576789").split())

)
