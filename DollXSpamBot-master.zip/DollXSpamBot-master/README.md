<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif"></a>
# [𝘿𝙤𝙡𝙡 ✘ 𝙎𝙥𝙖𝙢]

  <img src="https://readme-typing-svg.herokuapp.com?color=F77247&width=420&lines=𝙰+𝚃𝚎𝚕𝚎𝚐𝚛𝚊𝚖+𝚂𝚙𝚊𝚖𝙱𝚘𝚝+𝙾𝚙𝚎𝚗+𝚂𝚘𝚞𝚛𝚌𝚎;𝚠𝚛𝚒𝚝𝚝𝚎𝚗+𝙸𝚗+Telethon%E2%9D%A4%EF%B8%8F">
</p> 

![logo](https://telegra.ph/file/f8d63b1dc5676fc9988f1.jpg)
<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif"></a>

- [x] ☯︎ ғᴀsᴛ ᴀɴᴅ sᴛᴀʙʟᴇ ☯︎
- [x] Deploy 10 Bots in One time 🔥
- [x] Deploy Using Bot Token 
- [x] Porn Spam | Hang Spam `new`
- [x] Soon Inline Spam `soon`

# Hᴏsᴛɪɴɢ
  <img src="https://readme-typing-svg.herokuapp.com?color=F77247&width=420&lines=𝙷𝚘𝚠+𝚃𝚘+𝙳𝚎𝚙𝚕𝚘𝚢+DollX_SpamBot+𝚂𝚘𝚞𝚛𝚌𝚎;𝙷𝚘𝚠+𝚃𝚘+𝙳𝚎𝚙𝚕𝚘𝚢+DollX_SpamBot+𝚂𝚘𝚞𝚛𝚌𝚎%E2%9D%A4%EF%B8%8F">
</p>

<p align="center"><a href="https://heroku.com/deploy?template=https://github.com/dominator454/BOTDEPLOY"><img align="center" alt="Heroku" width="92px" src="https://www.nicepng.com/png/full/223-2233246_heroku-logo-salesforce-heroku.png"></p>

## [![Deploy on Railway](https://railway.app/button.svg)](https://railway.app/new/template/3FQMmO?referralCode=uT7IB5)

#### [THIS ALSO FOR HEROKU](https://heroku.com/deploy?template=https://github.com/dominator454/BOTDEPLOY) 

## What Is DollX_SpamBot

<b>DollX_SpamBot Is An Telethon Bassed SpamBot That Spam In Telegram Groups And personal Chats, this bot is specially used by clan users when ever fights starts between two clan or between two users</b>

## Is Safe To Deploy

<b>This SpamBot Is Fully Created On Telethon And Working With Telethon So Bot Is Fully Safe To Deploy, We Gives Deployment To Heroku And Also In Vps For Better Spam Experience</b>

# CᴏɴᴛʀɪBᴜᴛᴏʀꜱ

![GitHub Contributors Image](https://contrib.rocks/image?repo=Team-Deadly/DEADLY-SPAMBOT)

<a href="https://www.youtube.com/watch?v=dQw4w9WgXcQ"><img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif"></a>
